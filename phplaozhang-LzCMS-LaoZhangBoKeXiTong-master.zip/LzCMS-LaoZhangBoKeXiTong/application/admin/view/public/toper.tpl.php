<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <title>LzCMS-后台管理中心</title>
    <link rel="stylesheet" href="/static/layui/css/layui.css">
    <link rel="stylesheet" href="/static/css/global.css">
    <script type="text/javascript" src="/static/layui/layui.js"></script>
</head>
<body>