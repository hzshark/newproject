<?php
return array(
	'type'   =>'mysql',
	'hostname'   =>'127.0.0.1',
	'hostport'   =>'3306',
	'database'   =>'lzcms',
	'username'   =>'root',
	'password'   =>'root',
	'prefix'     =>'lz_',
	'charset'    => 'utf8',
	'resultset_type' => 'array',
	'fields_strict'  => true,
);